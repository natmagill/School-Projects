import pandas as pd
import sqlalchemy
connection_string = sqlalchemy.URL.create(
    "mysql+pymysql",
    host="mariadb-compx0.oit.utk.edu",
    port=3306,
    database="aspannba_bas476",
    username="nmagill",
    password="wqc123",
)
print(connection_string)

engine = sqlalchemy.create_engine(connection_string)
pd.read_sql("SHOW TABLES", engine)

april = pd.read_sql("SELECT * FROM so_posts_april", engine)
april.shape
may = pd.read_sql("SELECT * FROM so_posts_may", engine)
may.shape
april_may = pd.concat([april,may], ignore_index=True)
april_may.shape
csv_file_name = 'full_data.csv'

april_may.to_csv(csv_file_name, index=False)

full = pd.read_csv('full_data.csv')

june = pd.read_sql("SELECT * FROM so_posts_june", engine)
june.head()
all_three = pd.concat([april,may,june], ignore_index=True)

scores_type_1 = all_three.sort_values("Score", ascending=False)

top_scores_type_1 = scores_type_1.head(15)

top_scores_type_1
csv_file_name = 'summarized_data.csv'

top_scores_type_1.to_csv(csv_file_name, index=False)

summarized = pd.read_csv('summarized_data.csv')
